const colorsOfTheRainbow = [
    "red", "orange", "yellow", "green", "blue", "indigo", "violet"];

new Vue({
    el: '#colors',
    data: {
        rainbow: colorsOfTheRainbow
    }
});