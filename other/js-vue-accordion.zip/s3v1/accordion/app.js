new Vue({
    el: '',
    data: {

    },
    methods: {

    }
});